import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-info',
  templateUrl: './company-info-detail.component.html',
  styleUrls: ['./company-info-detail.component.scss']
})
export class CompanyInfoDetailComponent implements OnInit {
  @Input() companyDetails :any;
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
}