import { Injectable } from '@angular/core';
import {
  HttpClient,
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SearchService {
  constructor(private http: HttpClient) {}

  public getCompanyNameUsingLogo(request:any): Observable<any> {
    const url = 'https://vision.googleapis.com/v1/images:annotate?key=AIzaSyB0fzpNESlqg06ApKSHCSN94lGH7T75h08';
    return this.http.post<any>(url, request);
  }

  public getCompanyDetailsUsingName(name:any): Observable<any> {
    const url = 'https://localhost:44396/api/FMP?name='+name;
    return this.http.get<any>(url);
  }
}
