import { Component, OnInit } from '@angular/core';
import { WebcamImage } from 'ngx-webcam';
import { Observable, Subject } from 'rxjs';
import { SearchService } from './search-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  constructor(private searchService:SearchService)
  {}
  ngOnInit(): void {
    this.checkPermissions();
  }

  stream: any = null;
  status: any = null;
  trigger: Subject<void> = new Subject();
  previewImage: string = '';
  previewImageBase64: string = '';
  btnLabel: string = 'Capture image';
  companyName="";
  error=false;
  companyDetails:any;
  loading=false;

  get $trigger(): Observable<void> {
    return this.trigger.asObservable();
  }

  snapshot(event: WebcamImage) {
   // console.log(event);
    this.previewImageBase64=event.imageAsBase64;
    this.previewImage = event.imageAsDataUrl;
    //this.btnLabel = 'Re capture image and Search'
  }
  checkPermissions() {
    navigator.mediaDevices.getUserMedia({
      video: {
        width: 500,
        height: 500
      }
    }).then((res) => {
      //console.log("response", res);
      this.stream = res;
      this.status = 'My camera is accessing';
      this.btnLabel = 'Click to Capture and Search';
    }).catch(err => {
      //console.log(err);
      if(err?.message === 'Permission denied') {
        this.status = 'Permission denied please try again by approving the access';
      } else {
        this.status = 'You may not having camera system, Please try again ...';
      }
    })
  }

  captureImage() {
    this.companyDetails=[];
    this.loading=true;
    this.trigger.next();
    this.search();
  }

  search() {
    this.error=false;
    console.log(this.previewImage);
    const request={
      requests: [
        {
          image: {
            content: this.previewImageBase64
          },
          features: [
            {
              type: "LOGO_DETECTION"
            }
          ]
        }
      ]
    };
    this.searchService.getCompanyNameUsingLogo(request).subscribe((data: any) => {
      //console.log(data);
      if(data.responses && data.responses.length && data.responses[0]?.logoAnnotations?.length)
      {
        this.companyName=data.responses[0]?.logoAnnotations[0]?.description;
        this.getCompanyDetails();
      }else
      {
        this.error=true;
        this.loading=false;
        //this.companyName="Not able to find the company !"
        //this.btnLabel = 'Re capture image and Search'
      }
    });
    
  }

  getCompanyDetails()
  {
    this.searchService.getCompanyDetailsUsingName(this.companyName).subscribe((data: any) => {
      console.log(data);
      this.loading=false;
      this.companyDetails=data;
      if(data && data.length==0)
      {
        this.error=true
      }
      
    },
    (err:any)=>{
      console.log(err);
      this.error=true
      this.loading=false;
    })
    ;
  }
}
