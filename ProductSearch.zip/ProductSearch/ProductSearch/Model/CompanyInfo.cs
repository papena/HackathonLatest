﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductSearch.Model
{
    public class CompanyInfo
    {
        public string symbol { get; set; }
        public string name { get; set; }
        public string currency { get; set; }
        public string stockExchange { get; set; }
        public string price { get; set; }
        public string companyName { get; set; }
        public string website { get; set; }
        public string description { get; set; }
        public string shortDescription { get; set; }
        public string sector { get; set; }
        public bool defaultImage { get; set; }
        public string ipoDate { get; set; }
        public string image { get; set; }

    }
}
