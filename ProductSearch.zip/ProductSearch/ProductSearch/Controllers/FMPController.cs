﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductSearch.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace ProductSearch.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FMPController : ControllerBase
    {
        static HttpClient client = new HttpClient();

        [HttpGet]
        public async Task<List<CompanyInfo>> GetCompanyDetailsByName(string name,string exchange, int limit)
        {
            return await ProcessCompanyData(name);
        }
        //public async Task<List<CompanyInfo>> GetCompanyDetails(string name)
        //{
        //    return await ProcessCompanyData();
        //}
        private async Task<CompanyDetailsResponse> GetCompanyDetailsBySymbol(string symbol)
        {
            string url = "https://financialmodelingprep.com/api/v3/profile/"+ symbol + "?apikey=dQqApcGzu2Ca2VsOjjuCE6Dra4eAEH2C";
            List<CompanyDetailsResponse> data = null;
            try
            {
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    data = await response.Content.ReadAsAsync<List<CompanyDetailsResponse>>();
                    if(data !=null && data.Count>0)
                    {
                        return data[0];
                    }
                }
            }
            catch(Exception ex)
            {

            }
            return null;
        }

        private async Task<List<CompanyInfo>> ProcessCompanyData(string name)
        {
            List<CompanyInfo> result = new List<CompanyInfo>();
            try
            {
                string url = "https://financialmodelingprep.com/api/v3/search?query=" + name + "&apikey=dQqApcGzu2Ca2VsOjjuCE6Dra4eAEH2C";
                List<SearchResponse> companySymbolsList = null;
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    companySymbolsList = await response.Content.ReadAsAsync<List<SearchResponse>>();
                    if(companySymbolsList != null && companySymbolsList.Count>0)
                    {
                        foreach (var companySymbol in companySymbolsList)
                        {
                            var detailResponse = await this.GetCompanyDetailsBySymbol(companySymbol.symbol);
                            if(detailResponse !=null && detailResponse.companyName !=null)
                            {
                                CompanyInfo info = new CompanyInfo();
                                info.symbol = companySymbol.symbol;
                                info.stockExchange = companySymbol.stockExchange;
                                info.currency = companySymbol.currency;
                                info.companyName = detailResponse.companyName;
                                info.defaultImage = detailResponse.defaultImage;
                                info.description = detailResponse.description;
                                info.ipoDate = detailResponse.ipoDate;
                                info.sector = detailResponse.sector;
                                info.website = detailResponse.website;
                                info.price = "$"+detailResponse.price;
                                info.image = detailResponse.image;
                                info.shortDescription = detailResponse.description != null ? detailResponse.description.Substring(0, 300) : "";
                                result.Add(info);

                            }

                        }

                    }

                }
            }catch(Exception ex)
            {

            }
            return result;

        }

    }
}
